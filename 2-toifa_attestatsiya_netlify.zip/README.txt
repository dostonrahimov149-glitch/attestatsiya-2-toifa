NETLIFY DEPLOY — 2-TOIFA TESTI

1) ZIP arxivni oching.
2) Netlify Drop: https://app.netlify.com/drop sahifasiga kiring.
3) index.html joylashgan papkani sahifaga tashlang.
4) Sayt tayyor bo‘ladi.

50 savol, 105 daqiqa. Ism-familiya testdan oldin kiritiladi. Savollar alohida ko‘rinadi, chap tomonda raqamli navigatsiya mavjud. Yakunda natija va javoblar tahlili chiqadi.
